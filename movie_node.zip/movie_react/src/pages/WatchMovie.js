import Watching from '../components/Movies/WatchMovie'

const WatchMovie = () => {
    return <section>
        <Watching />
    </section>
}

export default WatchMovie