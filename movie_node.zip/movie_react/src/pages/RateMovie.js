import Rating from '../components/Movies/Rating'

const RateMovie = () => {
    return <section>
        <Rating />
    </section>
}

export default RateMovie