
import Auth from '../components/Auth/Auth'

const Login = () => {
    return <section>
        <Auth />
    </section>
}

export default Login