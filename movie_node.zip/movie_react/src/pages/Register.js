const Register = () => {
    return <section>
        <h1>Register !</h1>
    </section>
}

export default Register