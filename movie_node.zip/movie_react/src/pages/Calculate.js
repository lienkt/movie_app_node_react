import Calculate from '../components/Calculate/Calculate'

export default () => {
    return (
        <Calculate />
    )
}